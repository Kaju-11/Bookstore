public class Book {
    public int getBookPrice()
    {
        return bookPrice;
    }
    public void setBookPrice(int bookPrice)
    {
        this.bookPrice=bookPrice;
    }
    enum bookType{
        Poetry,
        Romance,
        Fantasy,
        Horror,
        Classics

    }
public Book(String bookName,bookType bookType)
{
    setBookType(bookType);
    setBookName(bookName);
    switch(bookType)
    {
        case Classics->setBookPrice(400);
        case Fantasy->setBookPrice(150);
        case Romance->setBookPrice(390);
        case Horror->setBookPrice(375);
        case Poetry->setBookPrice(490);
        default-> System.out.println("Invalid Type");


    }
    setBookPrice(bookPrice);

}
private String bookName;
    private bookType bookType;
    private int bookPrice;
    public String getBookName()
    {
        return bookName;
    }
    public void setBookName (String bookName)
    {
        this.bookName=bookName;
    }
    public void setBookType(Book.bookType bookType)
    {
        this.bookType=bookType;
    }
}
