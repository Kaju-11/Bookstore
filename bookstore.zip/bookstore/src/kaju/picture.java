package kaju;

public class picture {
}
