import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

class Image extends JFrame{
    JLabel l4;
    ImageIcon book;
    Image()
    {
         book = new ImageIcon(this.getClass().getResource("/book2.jpg"));
        l4=new JLabel(book);
        l4.setSize(400,400);
        add(l4);
    }
}

class Login  extends JFrame
{

    JTextField t1,t2;
//ImageIcon book;


    JButton b1;
    JLabel l1,l2,l3;
    Login()
    {
       // book=new ImageIcon(this.getClass().getResource("/book2.jpg"));
        setLayout(null);
        //setDefaultCloseOperation(EXIT_ON_CLOSE);
       // setDefaultLookAndFeelDecorated();
       // l4=new JLabel(book);

       // l4.setSize(200,300);
        l1= new JLabel("Login");
        l1.setFont(new Font("Times New Roman" ,Font.BOLD,30));
        l1.setForeground(Color.BLUE);
        l1.setBounds(100,10,300,34);

//add(l4);
        add(l1);
        t1=new JTextField(60);
        t2=new JPasswordField(60);
        b1=new JButton("SignIn");
        b1=new JButton("Login");

        t1.setBounds(100,60,120,30);
        t2.setBounds(100,100,120,30);
        b1.setBounds(120,140,80,30);
        l2=new JLabel("");
        l2.setBounds(272,80,300,30);
        l3=new JLabel("");
        l3.setBounds(250,120,300,30);
        add(l3);
        add(l2);
        add(t1);
        add(t2);
        add(b1);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(t1.getText().toString().equals("OOP")&&t2.getText().toString().equals("OOP")) {
                    l2.setText(" Welcome to  ");
                    l2.setFont(new Font("Times New Roman" ,Font.BOLD,30));
                    l2.setForeground(Color.BLUE);
                    l3.setText("GYAN GANGA");
                    l3.setFont(new Font("Times New Roman" ,Font.BOLD,30));
                    l3.setForeground(Color.DARK_GRAY);
                }
                else {
                    l2.setText("Invalid Username or Password ");
                    l2.setFont(new Font("Times New Roman" ,Font.BOLD,16));
                    l2.setForeground(Color.RED);
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

}

public class Main extends JDialog {

    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JPasswordField passwordField1;
    private JButton continueButton;
    private JPanel paymentpanel;
    private JLabel bad;
    //private JTextField textField4;

    public Main(JFrame parent) {
        super(parent);
        setTitle("Payment");
       // bad = new JLabel("");
       // bad.setBounds(250,120,300,30);
      //  add(bad);
        setVisible(true);
        setContentPane(paymentpanel);
        setMinimumSize(new Dimension(974,374));
        setModal(true);
        setLocationRelativeTo(parent);
        setVisible(true);
        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                    if((textField2.getText().toString()).length()!=16)
                    {
                        bad.setText("BAD CREDENTIALS :Enter valid data");
                        bad.setFont(new Font("Times New Roman" ,Font.BOLD,16));
                        bad.setForeground(Color.RED);
                        Toolkit.getDefaultToolkit().beep();
                    }
                    else if((passwordField1.getText().toString()).length()!=3)
                    {
                        bad.setText("BAD CREDENTIALS");
                        bad.setFont(new Font("Times New Roman" ,Font.BOLD,16));
                        bad.setForeground(Color.RED);
                        Toolkit.getDefaultToolkit().beep();
                    }
                    else {
                        bad.setText("PAYMENT SUCCESSFULL");
                        bad.setFont(new Font("Times New Roman" ,Font.BOLD,16));
                        bad.setForeground(Color.MAGENTA);

                    }
            }
        });
    }

        //System.out.println("Hello world!");
        public static ArrayList<User> Users =new ArrayList<>();
        public static ArrayList<Book> books=new ArrayList<>();
      //  books.ensureCapacity(67);
       // ensureCapacity(78);
        public static User activeUser;
        public static int cart;
        public static void createBooks() {
            Book book = new Book("MILK AND HONEY", Book.bookType.Poetry);
            Book book1 = new Book("BOOK OF UNSAID WORDS", Book.bookType.Poetry);
            Book book2 = new Book("THE MOON", Book.bookType.Poetry);
            books.add(book);
            books.add(book1);
            books.add(book2);
            Book book3 = new Book("RED, WHITE & ROYAL BLUE", Book.bookType.Romance);
            Book book4 = new Book("ELEANOR AND PARK", Book.bookType.Romance);
            Book book5 = new Book("THE SELECTION", Book.bookType.Romance);
            books.add(book3);
            books.add(book4);
            books.add(book5);
            Book book6 = new Book("THE HOBBIT", Book.bookType.Fantasy);
            Book book7 = new Book("THE GAME OF THRONES", Book.bookType.Fantasy);
            Book book8 = new Book("A CLASH OF KINGS", Book.bookType.Fantasy);
            books.add(book6);
            books.add(book7);
            books.add(book8);
            Book book9 = new Book("THE HOUSE OF SECRETS", Book.bookType.Horror);
            Book book10 = new Book("WHEN THE DEVIL WHISPERS", Book.bookType.Horror);
            Book book11 = new Book("THE MAGICAL BOOK", Book.bookType.Horror);
            books.add(book9);
            books.add(book10);
            books.add(book11);
            Book book12 = new Book("PRIDE AND PREJUDICE", Book.bookType.Classics);
            Book book13 = new Book("TO KILL A MOCKINGBIRD", Book.bookType.Classics);
            Book book14 = new Book("LITTLE WOMEN", Book.bookType.Classics);
            books.add(book12);
            books.add(book13);
            books.add(book14);
        }
public static void createUsers()
            {
                User OOP = new User("Password", "Name", User.UserType.ADMIN);
                Users.add(OOP);
                User kaju = new User("Password", "Name", User.UserType.USER);
                Users.add(kaju);
            }
            public static void login()
    {
        for(User User:Users)
        {
            Scanner scanner=new Scanner(System.in);
            System.out.println("\t\t\t\tUsername:");
            String Username =scanner.next();
            System.out.println("\t\t\t\tPassword:");
            String password =scanner.next();
            if(User.getUsername().equals(Username)&&User.getPassword().equals(password))
            {
                System.out.println("****************You have been logged inn SUCCESSFULLY****************");
                activeUser=User;
            }
        }
    }
    public static void register ()
    {
        Scanner scanner=new Scanner(System.in);
        System.out.println("\t\t\t\tUsername:");
        String Username=scanner .next();
        System.out.println("\t\t\t\tPassword:");
        String password=scanner.next();
        User newUser=new User(Username,password,User.UserType.USER);
        activeUser =newUser;
        cart+=30;
        Users.add(newUser);
        System.out.println("****************You have registered SUCCESSFULLY*************");
    }
    public static void addBookToCart() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        for (int i = 0; i < 15; i++) {
            System.out.println(i + "-" + books.get(i).getBookName());

        }
        choice = scanner.nextInt() % 15;
        if (activeUser.getType() == User.UserType.ADMIN || activeUser.getType() == User.UserType.USER) {
            cart += books.get(choice).getBookPrice();
        } else {
            cart += books.get(choice).getBookPrice() * 1.5;
        }
        Main pay=new Main(null);
        System.out.println("\t\t\t\tPayable amount: " + cart);
        //Main pay=new Main(null);
        if (activeUser.getType() == User.UserType.CUSTOMER) {
            choice = 0;
            System.out.println("\t\t\t\tDo you want to login as User?[1:YES2:NO]");
            choice = scanner.nextInt();
            if (choice == 1) {
                register();
            } else {
                System.out.println("\t\t\t\tDo you want to buy more book or exit?(Press 1 to exit.)");
                int option = scanner.nextInt();
                if (option == 1) {
                    System.out.println("*****************Thankyou for choosing us.Hope to see you again dear customer*************");
                    System.exit(0);
                }
            }
        }
    }

public  static void pay()
        {
            System.out.println("*****************Thank you "+activeUser.getUsername()+"!"+"You payed"+cart+"Rs***************");
            cart=0;
        }
        public static void main(String [] args)
        {
            /*
            Image i=new Image();
            i.setBounds(800,900,900,800);
            i.setVisible(true);
            */
            Login l=new Login();
            l.setBounds(400,200,500,300);
            l.setVisible(true);

            createUsers();
            createBooks();
            Scanner scanner =new Scanner(System.in);
            while(true)
            {
                int choice =0;
                if(activeUser==null)
                {
                    System.out.println("**************************Welcome to the Bookstore**************************");
                    System.out.println("\t\t\t\tBelow are some  Options:");
                    String options="\t\t\t\t1-Login as an user\n"+"\t\t\t\t2-Buy as a customer\n"+"\t\t\t\t3-Exit the system";
                    System.out.println(options);
                    choice =scanner.nextInt();
                    if(choice==1)
                    {
                        login();

                    }
                    else if(choice==2)
                    {
                        activeUser=new User("" ,"",User.UserType.CUSTOMER);
                        addBookToCart();
                        //Main pay=new Main(null);
                    }
                    else {
                        break;
                    }
                }
                else
                {
                    System.out.println("\t\t\t\t1-Buy a Book");
                    if(cart!=0)
                    {
                        System.out.println("\t\t\t\t2-Pay");
                        System.out.println("\t\t\t\t3-Shut down");
                    }
                    else
                    {
                        System.out.println("\t\t\t\t2-Shut down");
                    }
                    choice =scanner.nextInt();
                    if(choice==1)
                    {
                        addBookToCart();
                        Main pay=new Main(null);

                    }
                    else if(cart!=0&&choice==2)
                    {
                        Main pay=new Main(null);
                        pay();
                    }
                    else
                    {
                        System.out.println("****************Thank you for choosing us dear customer .Hope to see You again************");
                        break;
                    }
                }
            }
        }
    }





